const mineflayer = require('mineflayer');

function startBot() {
  const bot = mineflayer.createBot({
    host: 'your-server.aternos.me', // replace with your Aternos IP
    port: 25565,
    username: 'AFK_Bot_01',
    auth: 'offline'
  });

  bot.once('spawn', () => {
    console.log('✅ Bot spawned.');
    setInterval(() => {
      bot.setControlState('jump', true);
      setTimeout(() => bot.setControlState('jump', false), 500);
    }, 10000);
  });

  bot.on('end', () => {
    console.log('⚠️ Bot disconnected. Reconnecting...');
    setTimeout(startBot, 5000);
  });

  bot.on('error', err => {
    console.error('❌ Error:', err.message);
  });
}

startBot();